/*
Developer: D.Loranger
Date Modified: 2024-Nov-02
File purpose: Basic hello world application to get familiar with the environment.

*/

#include <iostream>

int main() {
    // Design Requirement: 'write a code that outputs �Hello, World!� in C++'
    // Design comment: the endl is not specified, included for cleanliness on console
    std::cout << "Hello, World!" << std::endl;
    return 0;
}