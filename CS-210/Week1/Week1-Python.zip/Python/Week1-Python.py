#
# Developer: D.Loranger
# Date Modified: 2024-Nov-02
# File purpose: Basic hello world application to get familiar with the environment.
#

#def main is not really necessary, but good practice for ensuring code clumping in functions
def main():

  # Design Requirement: 'write a code that outputs “Hello, World!” in C++'
  # Design comment: the endl is not specified, included for cleanliness on console
  print ("Hello, World!")
  
main()

input()